-- 1- Crear la tabla 'autos' en una nueva base de datos (Vehiculos) con el siguiente detalle:

-- 	codigo	INTEGER y PK
-- 	marca	VARCHAR(25)
-- 	modelo	VARCHAR(25)
-- 	color	VARCHAR(25)
-- 	anio	INTEGER
-- 	precio	DOUBLE

--  nota: (anio - año) seguramente tu computadora tiene soporte para la letra ñ,
--        pero muchas instalaciones (ej: web host alquilados) pueden que no tenga soporte para esa letra.
-- 		  en programación se acostumbra a usar los caracteres menores a 128 en la tabla ASCII.
drop database if exists vehiculos;
create database vehiculos;
use vehiculos;
create table autos(
    codigo int auto_increment primary key,
    marca varchar(25),
    modelo varchar(25),
    color varchar(25),
    anio int,
    precio double
);

-- 2- Agregar el campo patente despues del campo modelo.
alter table autos add patente varchar(12) after modelo;
describe autos;

-- 3- Cargar la tabla con 15 autos (hacerlo con MySQL WorkBench o el INSERT INTO).
INSERT INTO autos (marca, modelo, patente, color, anio, precio) VALUES
('Toyota', 'Corolla', 'ABC123', 'Rojo', 2020, 20000.00),
('Honda', 'Civic', 'XYZ456', 'Azul', 2019, 22000.00),
('Ford', 'Fiesta', 'LMN789', 'Negro', 2021, 18000.00),
('Chevrolet', 'Onix', 'QRS321', 'Blanco', 2022, 19000.00),
('Nissan', 'Versa', 'TUV654', 'Gris', 2020, 17500.00),
('Hyundai', 'Elantra', 'JKL987', 'Verde', 2021, 21000.00),
('Kia', 'Seltos', 'OPQ123', 'Naranja', 2022, 23000.00),
('Volkswagen', 'Polo', 'RST456', 'Amarillo', 2018, 16000.00),
('Mazda', '3', 'UVW789', 'Rojo', 2019, 20500.00),
('Subaru', 'Impreza', 'XYZ321', 'Azul', 2020, 24000.00),
('Peugeot', '208', 'ABC456', 'Blanco', 2021, 17000.00),
('Renault', 'Clio', 'DEF123', 'Negro', 2022, 16500.00),
('Fiat', 'Punto', 'GHI456', 'Verde', 2018, 15000.00),
('Mercedes-Benz', 'Clase A', 'JKL321', 'Gris', 2021, 35000.00),
('Audi', 'A3', 'MNO654', 'Negro', 2020, 33000.00),
('Toyota', 'Camry', 'ABC001', 'Rojo', 2021, 25000.00),
('Honda', 'Accord', 'XYZ002', 'Azul', 2020, 27000.00),
('Ford', 'Mustang', 'LMN003', 'Negro', 2022, 35000.00),
('Chevrolet', 'Malibu', 'QRS004', 'Blanco', 2019, 22000.00),
('Nissan', 'Altima', 'TUV005', 'Gris', 2021, 24000.00),
('Hyundai', 'Sonata', 'JKL006', 'Verde', 2020, 23000.00),
('Kia', 'Sportage', 'OPQ007', 'Naranja', 2022, 32000.00),
('Volkswagen', 'Jetta', 'RST008', 'Amarillo', 2018, 19000.00),
('Mazda', 'CX-5', 'UVW009', 'Rojo', 2021, 30000.00),
('Subaru', 'Forester', 'XYZ010', 'Azul', 2020, 28000.00),
('Peugeot', '3008', 'ABC011', 'Blanco', 2019, 21000.00),
('Renault', 'Koleos', 'DEF012', 'Negro', 2022, 24000.00),
('Fiat', '500', 'GHI013', 'Verde', 2018, 15000.00),
('Mercedes-Benz', 'Clase C', 'JKL014', 'Gris', 2021, 40000.00),
('Audi', 'Q3', 'MNO015', 'Negro', 2020, 37000.00),
('BMW', 'X1', 'PQR016', 'Rojo', 2022, 45000.00),
('Volkswagen', 'Tiguan', 'STU017', 'Azul', 2021, 36000.00),
('Honda', 'HR-V', 'VWX018', 'Blanco', 2020, 23000.00),
('Toyota', 'RAV4', 'YZA019', 'Gris', 2021, 31000.00),
('Nissan', 'Rogue', 'BCD020', 'Verde', 2022, 29000.00),
('Chevrolet', 'Equinox', 'EFG021', 'Negro', 2020, 26000.00),
('Ford', 'Explorer', 'HIJ022', 'Rojo', 2021, 40000.00),
('Hyundai', 'Tucson', 'KLM023', 'Azul', 2022, 35000.00),
('Kia', 'Telluride', 'NOP024', 'Blanco', 2021, 45000.00),
('Subaru', 'Outback', 'QRS025', 'Gris', 2020, 32000.00),
('Volkswagen', 'Atlas', 'TUV026', 'Verde', 2022, 37000.00),
('Mazda', 'CX-30', 'WXY027', 'Negro', 2021, 30000.00),
('Peugeot', '508', 'ZAB028', 'Rojo', 2019, 25000.00),
('Renault', 'Captur', 'CDE029', 'Azul', 2020, 18000.00),
('Fiat', 'Panda', 'FGH030', 'Blanco', 2021, 14000.00),
('Mercedes-Benz', 'GLE', 'IJK031', 'Gris', 2022, 65000.00),
('Audi', 'A4', 'LMN032', 'Negro', 2021, 47000.00),
('BMW', '3 Series', 'OPQ033', 'Rojo', 2020, 55000.00),
('Toyota', 'Highlander', 'RST034', 'Azul', 2022, 38000.00),
('Honda', 'Pilot', 'UVW035', 'Blanco', 2021, 42000.00),
('Nissan', 'Murano', 'XYZ036', 'Gris', 2020, 35000.00),
('Chevrolet', 'Tahoe', 'ABC037', 'Verde', 2022, 70000.00),
('Ford', 'F-150', 'DEF038', 'Negro', 2021, 45000.00),
('Hyundai', 'Palisade', 'GHI039', 'Rojo', 2022, 46000.00),
('Kia', 'Carnival', 'JKL040', 'Azul', 2021, 39000.00),
('Subaru', 'Ascent', 'MNO041', 'Blanco', 2020, 36000.00),
('Volkswagen', 'ID.4', 'PQR042', 'Gris', 2021, 40000.00),
('Mazda', 'MX-5', 'STU043', 'Verde', 2022, 30000.00),
('Peugeot', '2008', 'VWX044', 'Negro', 2019, 17000.00),
('Renault', 'Zoe', 'YZA045', 'Rojo', 2020, 22000.00),
('Fiat', 'Tipo', 'BCD046', 'Azul', 2021, 16000.00),
('Mercedes-Benz', 'GLC', 'EFG047', 'Blanco', 2022, 55000.00),
('Audi', 'Q5', 'HIJ048', 'Gris', 2021, 49000.00),
('BMW', 'X3', 'KLM049', 'Rojo', 2022, 52000.00),
('Toyota', 'Sienna', 'NOP050', 'Azul', 2021, 38000.00);

use vehiculos;
-- 4- Realizar las siguientes consultas:
-- 	a. obtener el precio máximo.
select max(precio) precio_máximo from autos;
-- 	b. obtener el precio mínimo.
select min(precio) precio_mínimo from autos;
-- 	c. obtener el precio mínimo entre los años 2010 y 2018.
select min(precio) precio_mínimo from autos where anio between 2010 and 2018;
-- 	d. obtener el precio promedio.
select replace(round(avg(precio),2),'.',',') precio_promedio from autos;
-- 	e. obtener el precio promedio del año 2016.
select replace(round(avg(precio),2),'.',',') precio_promedio from autos where anio=2016;
-- 	f. obtener la cantidad de autos.
select count(*) cantidad from autos;
-- 	g. obtener la cantidad de autos que tienen un precio entre $235.000 y $240.000.
select count(*) cantidad from autos where precio between 235000 and 240000;
-- 	h. obtener la cantidad de autos que hay en cada año.
select anio año, count(*) cantidad from autos group by anio;
-- 	i. obtener la cantidad de autos y el precio promedio en cada año.
select anio año, count(*) cantidad, replace(round(avg(precio),2),'.',',') precio_promedio 
        from autos group by anio;
-- 	j. obtener la suma de precios y el promedio de precios según marca.
select  marca, 
        replace(round(sum(precio),2),'.',',') total, 
        replace(round(avg(precio),2),'.',',') precio_promedio 
        from autos 
        group by marca; 
--  k. informar los autos con el menor precio.
select * from autos where precio=(select min(precio) from autos);
--  l. informar los autos con el menor precio entre los años 2016 y 2018.
select * from autos 
        where anio between 2016 and 2018 
        and precio=(select min(precio) from autos where anio between 2016 and 2018);
-- m. listar los autos ordenados ascendentemente por marca,modelo,año.
select * from autos order by marca, modelo, color;
--  n. contar cuantos autos hay de cada marca.
select marca, count(*) cantidad from autos group by marca;
--  o. borrar los autos del siglo pasado.
set sql_safe_updates=0;
delete from autos where anio<2000;
