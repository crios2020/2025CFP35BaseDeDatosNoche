-- Laboratorio 2

-- 1- Borrar si existe la base de datos Negocio.
drop database if exists negocio;
-- 2- Crear la base de datos Negocio.
create database negocio;
-- 3- Ingresar a la base de datos creada.
use negocio;
-- 4- Crear la tabla Clientes dentro de la base de datos con el siguiente detalle:

-- codigo		int auto_increment y PK
-- nombre		varchar(20) not null
-- apellido		varchar(20) not null
-- cuit			char(13)
-- direccion	varchar(50)
-- comentarios 	varchar(140)

-- PK significa Primary Key
drop table if exists clientes;
create table clientes (
    codigo int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    cuit char(13),
    direccion varchar(50),
    comentarios varchar(140)
);

-- 5- Crear la tabla Facturas dentro de la base de datos con el siguiente detalle:

-- Letra		char y PK
-- Numero		integer y PK
-- Fecha		date
-- Monto		double

-- observar que se esta declarando una clave primaria compuesta
-- es decir primary key(letra,codigo)
-- cada campo por si solo no es clave, ni tampoco identifica al registro
-- pero la suma de los dos forman la clave
create table facturas(
    letra char(1),
    numero int,
    fecha date,
    monto double,
    primary key(letra, numero)
);

-- 6- Crear la tabla Articulos dentro de la base de datos con el siguiente detalle:

-- Codigo		integer auto_increment y PK 
-- Nombre 		varchar(50)
-- Precio		double
-- Stock		integer
create table articulos(
    codigo  int auto_increment primary key,
    nombre varchar(50),
    precio double,
    stock int
);
-- 7- Cargar 5 registros aleatorios en cada tabla.
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
    ('Juan', 'Pérez', '20-12345678-9', 'Av. Siempre Viva 123', 'Cliente frecuente, siempre puntual.'),
    ('María', 'Gómez', '27-98765432-1', 'Calle Falsa 456', 'Interesada en promociones.'),
    ('Carlos', 'López', '30-19283746-2', 'Ruta 5 km 10', 'Solicitó información sobre productos.'),
    ('Ana', 'Martínez', '23-56473829-3', 'Paseo del Parque 789', 'Cliente nuevo, necesita asesoría.'),
    ('Pedro', 'Sánchez', '24-37482910-4', 'Calle de la Paz 101', 'Comentarios positivos sobre el servicio.');

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
    ('A', 1001, '2023-01-15', 2500.75),
    ('B', 2002, '2023-02-20', 1500.50),
    ('C', 3003, '2023-03-10', 3200.00),
    ('A', 1002, '2023-04-25', 1800.30),
    ('B', 2003, '2023-05-30', 2200.90);

INSERT INTO articulos (nombre, precio, stock) VALUES
('Laptop', 1200.99, 15),
('Mouse inalámbrico', 25.50, 50),
('Teclado mecánico', 75.00, 30),
('Monitor LED 24"', 200.75, 20),
('Impresora multifuncional', 150.00, 10);

-- 8- Mostrar las tablas que tiene la base de datos negocio.
show tables;

-- 9- Describir (detalle de campos - METADATO) cada una de las tablas de la base de datos.
describe clientes;
describe facturas;
describe articulos;

-- 10- Listar los registros de cada tabla.
select * from clientes;
select * from facturas;
select * from articulos;
