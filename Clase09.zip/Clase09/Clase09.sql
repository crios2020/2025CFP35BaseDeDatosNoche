-- Active: 1755642267207@@127.0.0.1@3306@negocio
use negocio;

-- Funciones de agrupamiento

-- Función max(arg)         arg:número, texto, fecha
select max(monto) from facturas;
select max(monto) monto_máximo from facturas;
select max(fecha) ultima_fecha from facturas;
select max(nombre) ultimo_nombre from clientes;

insert into clientes (nombre, apellido) values
    ('Sergio','Perez'),
    ('victor','Perez'),
    ('Victor','Perez'),
    ('ana','Perez'),
    ('Ana','Perez');

-- función min(arg)             arg:número, texto, fecha
select min(monto) monto_mínimo from facturas;
select min(fecha) primer_fecha from facturas;
select min(nombre) primer_nombre from clientes;
delete from clientes where nombre='victor';
select * from clientes;

-- función sum(arg)             arg:número
select sum(monto) total_facturado from facturas;

-- función avg(arg)             arg:número
select avg(monto) monto_promedio from facturas;
select round(avg(monto),2) monto_promedio from facturas;
select replace(round(avg(monto),2),'.',',') monto_promedio from facturas;

-- función count(*)
select count(*) cantidad from facturas;
select count(*) cantidad from clientes;
select count(direccion) cantidad from clientes;

select * from clientes;

-- Agrupamientos group by

-- Total facturado en cada letra
select letra, sum(monto) total from facturas where letra='A';
select letra, sum(monto) total from facturas where letra='B';
select letra, sum(monto) total from facturas where letra='C';

select letra, sum(monto) total from facturas group by letra;
select letra, replace(round(sum(monto),2),'.',',') total from facturas group by letra;

/*
        Letra       Total
        A           13302
        B           10664
        C            8200
*/

-- cantidad de personas en cada estado civil
select estado_civil, count(*) cantidad from padron where estado_civil='soltero';
select estado_civil, count(*) cantidad from padron where estado_civil='casado';
select estado_civil, count(*) cantidad from padron where estado_civil='viudo';
select estado_civil, count(*) cantidad from padron where estado_civil='divorciado';

select estado_civil, count(*) cantidad from padron group by estado_civil;

-- cantidad de personas en cada provincia
select provincia, count(*) cantidad from padron group by provincia;

-- cantidad de personas en cada ciudad
select provincia, ciudad, count(*) cantidad from padron group by provincia, ciudad;

-- Uso del having
select letra, replace(round(sum(monto),2),'.',',') total 
    from facturas 
    group by letra
    having sum(monto)>=10000;

-- subconsultas - subqueries
select max(precio) valor_máximo from articulos;

select * from articulos where precio=1312.08;

select * from articulos where precio=(select max(precio) from articulos);