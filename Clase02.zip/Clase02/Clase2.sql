-- Linea de comentarios
/* Bloque de comentarios */

show databases;		-- muestra las BDs de server

-- ; es el terminador de sentencia
-- CTROL - ENTER	para ejecutar

SHOW DATABASES;		-- lenguaje no case sensitive

drop database if exists clase01;		-- borra la base de datos clase01
create database clase01;				-- Crea la BD clase01 

use clase01;							-- Activa la BD

show tables;							-- Muestra el catalogo de tablas

-- borramos la tabla de clientes
drop table if exists clientes;

-- creamos la tabla clientes
create table clientes (
	codigo int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    cuit varchar(20),
    direccion varchar(50),
    comentarios varchar(150)
);

-- campos: son columnas
-- registros: con filas

describe clientes;					-- Muestra el metadato - describe la tabla

select * from clientes;				-- lista los registros de la tabla clientes

-- insertamos un registro en tabla clientes
insert into clientes (nombre, apellido, cuit, direccion) 
	values ('Ana','Gallardo','1234567','Lima 123');


-- extensión para MySQL MySQL cweijan