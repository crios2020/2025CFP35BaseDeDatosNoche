-- Uso de JOIN

select * from clientes;
select * from facturas;
insert into facturas values 
    ('a',2001,curdate(),67000,1),
    ('a',2002,curdate(),7000,1),
    ('a',2003,curdate(),6000,4);
-- Usando la base de datos negocio2 (solo tablas clientes y facturas).
use negocio;
-- 1-	Informar que clientes (codigo, nombre, apellido) han comprado en el día de hoy.
select distinct c.codigo, nombre, apellido 
    from clientes c join facturas f on c.codigo=f.codigo
    where fecha=curdate();
-- 2-	Informar la suma de los montos de cada cliente (código,nombre,apellido,total_comprado).
select c.codigo, nombre, apellido, sum(monto) total_comprado 
    from clientes c join facturas f on c.codigo=f.codigo
    group by c.codigo;
-- 3-	Informar cual es el cliente que más ha comprado (codigo, nombre, apellido).
select c.codigo, nombre, apellido, sum(monto) total_comprado 
    from clientes c join facturas f on c.codigo=f.codigo
    group by c.codigo 
    order by total_comprado
    limit 1;
-- 4-	Informar la cantidad de facturas de cada cliente (codigo, nombre, apellido,cantidad_facturas).
select c.codigo, nombre, apellido, count(*) cantidad_de_facturas 
    from clientes c join facturas f on c.codigo=f.codigo
    group by c.codigo; 
-- 5-	Informar quienes compraron el primer día de ventas (codigo, nombre, apellido).
select distinct c.codigo, nombre, apellido 
    from clientes c join facturas f on c.codigo=f.codigo
    where fecha=(select min(fecha) from facturas);
-- 6-	Informar que compro el cliente Juan Perez (letra,nro,fecha,monto).
select c.codigo, nombre, apellido, letra, numero, fecha, monto
    from clientes c join facturas f on c.codigo=f.codigo
    where nombre='Juan' and apellido='Perez';