
-- Uso de JOIN

select * from articulos;
insert into articulos values (null, 'Lampara 5w', 345, 50);
select * from detalles;
insert into detalles values 
	('A',1,112,12),
	('A',1002,112,2);
select * from facturas;
insert into facturas values ('B',10,curdate(),1000,2);
insert into detalles values 
	('B',10,1,12),
	('B',10,2,2);

-- Usando la base de datos negocio (usando todas las tablas).
use negocio;
-- 1- Informar quienes (nombre,apellido) compraron 'lamparas'.
select distinct c.codigo, c.nombre, c.apellido 
	from clientes c join facturas f on c.codigo=f.codigo
    join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo
	where a.nombre like '%lampara%';

-- 2- Informar que articulos compro 'Juan Perez'.
select distinct a.codigo, a.nombre, a.precio, a.stock 
	from clientes c join facturas f on c.codigo=f.codigo
    join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo
	where c.nombre='Juan' and c.apellido='Perez';

-- 3- Informar cuantas lamparas se vendieron.
select sum(cantidad) cantidad_lamparas_vendidas
	from detalles d join articulos a on d.codigo=a.codigo
	where a.nombre like '%lampara%';

-- 4- Informar cuantas unidades se vendieron en total en cada articulo.
select a.codigo, a.nombre, sum(cantidad) cantidad
	from detalles d join articulos a on d.codigo=a.codigo
	group by a.codigo;

-- 5- Informar la lista de artículos vendidos el día de hoy.
select DISTINCT  a.codigo, a.nombre, a.precio, a.stock
	from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo 
	where f.fecha=curdate();

-- 6- Informar la lista de artículos vendidos en este mes.
select DISTINCT  a.codigo, a.nombre, a.precio, a.stock
	from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo 
	where year(f.fecha)=year(curdate()) and month(f.fecha)=month(curdate());
-- 7- Informar la lista de artículos vendidos en este año y la cantidad vendida.
select DISTINCT  a.codigo, a.nombre, a.precio, a.stock, sum(cantidad)
	from facturas f join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo 
	where year(f.fecha)=year(curdate())
	group by a.codigo;
