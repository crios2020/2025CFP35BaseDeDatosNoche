show databases;
use negocio;
show tables;
describe clientes;
describe facturas;
describe articulos;
select * from clientes;
select * from facturas;
select * from articulos;

-- Rol DBA Data Base Administrator

-- Campo Clave Foranéa - Foreign Key
-- Agregamos el campo Clave Foranéa en facturas
alter table facturas add codigo int not null;

-- No existe control de integridad referencial
set sql_safe_updates=0;
update facturas set codigo=1;
update facturas set codigo=2504 where letra='a' and numero=1;
update facturas set codigo=1 where letra='a';
update facturas set codigo=2 where letra='b';
update facturas set codigo=3 where letra='c';
update facturas set codigo=4 where letra='f';

-- Agregamos la restricción de integridad referencial
alter table facturas
	add constraint fk_facturas_codigo_clientes
    foreign key(codigo)
    references clientes(codigo);

use negocio;
-- Consulta de producto cartesiano
select * from clientes, facturas;

select count(*) cantidad from clientes;                 -- 17
select count(*) cantidad from facturas;                 -- 10
select 17*10;                                           -- 170
select count(*) cantidad from clientes, facturas;       -- 170

-- Producto relacionado
select * from clientes, facturas where clientes.codigo=facturas.codigo;

select count(*) cantidad 
    from clientes, facturas 
    where clientes.codigo=facturas.codigo;              -- 10


-- uso del aleas
select * from clientes c, facturas f where c.codigo=f.codigo;

-- uso del Join
select * from clientes c join facturas f on c.codigo=f.codigo;


-- que compras realizó Juan Perez?
select c.codigo, nombre, apellido, letra, numero, fecha, monto 
    from clientes c join facturas f on c.codigo=f.codigo
    where nombre='Juan' and apellido='Perez';



-- Agregamos la tabla detalles
create table detalles(
    letra char(1),
    numero int,
    codigo int,
    cantidad int,
    primary key(letra, numero, codigo)
);

-- Declaramos las restricciones de FK
alter table detalles 
    add constraint fk_detalles_facturas
    foreign key(letra, numero)
    references facturas(letra,numero);

alter table detalles
    add constraint fk_detalles_articulos
    foreign key(codigo)
    references articulos(codigo);

select * from facturas;
select * from articulos;

insert into detalles values 
    ('A',1,1,4),
    ('A',1,3,10),
    ('A',1,4,1),
    ('A',2,2,1),
    ('A',2,3,11),
    ('A',1001,1,14),
    ('A',1001,2,4),
    ('A',1001,5,2),
    ('A',1002,1,7),
    ('A',1002,2,4);

-- Consulta del producto cartesiano
select * from clientes, facturas, detalles, articulos;
select count(*) cantidad from clientes;             -- 17
select count(*) cantidad from facturas;             -- 13
select count(*) cantidad from detalles;             -- 10
select count(*) cantidad from articulos;            -- 7

select 17*13*10*7;                                  -- 15470
select count(*) cantidad from clientes, facturas, detalles, articulos;              -- 15470

-- Producto relacionado
select * from clientes c join facturas f on c.codigo=f.codigo
    join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo;

select count(*) cantidad from clientes c join facturas f on c.codigo=f.codigo
    join detalles d on f.letra=d.letra and f.numero=d.numero 
    join articulos a on d.codigo=a.codigo;