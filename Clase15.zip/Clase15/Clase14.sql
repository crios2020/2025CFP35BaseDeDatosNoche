show databases;
use negocio;
show tables;
describe clientes;
describe facturas;
describe articulos;
select * from clientes;
select * from facturas;
select * from articulos;

-- Rol DBA Data Base Administrator

-- Campo Clave Foranéa - Foreign Key
-- Agregamos el campo Clave Foranéa en facturas
alter table facturas add codigo int not null;

-- No existe control de integridad referencial
set sql_safe_updates=0;
update facturas set codigo=1;
update facturas set codigo=2504 where letra='a' and numero=1;
update facturas set codigo=1 where letra='a';
update facturas set codigo=2 where letra='b';
update facturas set codigo=3 where letra='c';
update facturas set codigo=4 where letra='f';

-- Agregamos la restricción de integridad referencial
alter table facturas
	add constraint fk_facturas_codigo_clientes
    foreign key(codigo)
    references clientes(codigo);

use negocio;
-- Consulta de producto cartesiano
select * from clientes, facturas;

select count(*) cantidad from clientes;                 -- 17
select count(*) cantidad from facturas;                 -- 10
select 17*10;                                           -- 170
select count(*) cantidad from clientes, facturas;       -- 170

-- Producto relacionado
select * from clientes, facturas where clientes.codigo=facturas.codigo;

select count(*) cantidad 
    from clientes, facturas 
    where clientes.codigo=facturas.codigo;              -- 10


-- uso del aleas
select * from clientes c, facturas f where c.codigo=f.codigo;

-- uso del Join
select * from clientes c join facturas f on c.codigo=f.codigo;


-- que compras realizó Juan Perez?
select c.codigo, nombre, apellido, letra, numero, fecha, monto 
    from clientes c join facturas f on c.codigo=f.codigo
    where nombre='Juan' and apellido='Perez';
