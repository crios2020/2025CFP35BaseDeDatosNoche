-- Laboratorio 3
-- 1 - Ingrese a la base de datos negocio.
use negocio;

-- 2 - Ingrese 5 registros aleatorios en cada tabla.
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES 
('Juan', 'Pérez', '20-12345678-9', 'Av. Siempre Viva 742', 'Cliente frecuente'),
('María', 'Gómez', '20-87654321-0', 'Calle Falsa 123', 'Interesada en promociones'),
('Carlos', 'López', '20-11223344-5', 'Paseo de la Reforma 456', 'Requiere atención especial'),
('Ana', 'Martínez', '20-99887766-1', 'Av. Libertador 789', 'Prefiere contacto por correo'),
('Luis', 'Fernández', '20-55443322-8', 'Calle 9 de Julio 321', 'Solicitó información sobre productos');

INSERT INTO facturas (letra, numero, fecha, monto) VALUES 
('A', 10081, '2023-01-15', 1500.75),
('B', 20082, '2023-02-20', 2500.50),
('A', 10082, '2023-03-10', 3200.00),
('C', 30083, '2023-04-05', 1800.25),
('B', 20083, '2023-05-12', 760.80);

INSERT INTO articulos (nombre, precio, stock) VALUES 
('Laptop x4545', 1200.50, 15),
('Smartphone grgr242', 800.00, 30),
('Tablet', 450.25, 20),
('Impresora', 150.75, 10),
('Auriculares', 75.99, 50);

INSERT INTO articulos (nombre, precio, stock) VALUES ('Auriculares', 200, 50);

-- 3 - Basándose en la tabla artículos obtener los siguientes listados.

-- a-	artículos con precio mayor a 1000
SELECT * from articulos WHERE precio >=1000;

-- b-	artículos con precio entre 200 y 400 (usar < y >)
SELECT * from articulos where precio >= 200 and precio<= 400;
-- c-	artículos con precio entre 400 y 600 (usar BETWEEN)
select * from articulos where precio BETWEEN 400 and 600;
-- d-	artículos con precio = 200 y stock mayor a 30
select * from articulos where precio=200 and stock>30;
-- e-	artículos con precio (120,200,300) no usar IN
select * from articulos where precio=120 or precio=200 or precio=300;
-- f-	artículos con precio (120,200,300) usar el IN
select * from articulos where precio in (120,200,300);
-- g-	artículos que su precio no sea (120,200,300)
select * from articulos where precio not in (120,200,300);
-- h-   artículos que su precio mas iva(21 %) sea mayor a 100
select * from articulos where precio*1.21>=100;
-- i-   listar nombre y descripción de los artículos que no cuesten $100
select nombre from articulos where precio!=100;
-- j- 	artículos con nombre que contengan la cadena 'lampara' (usar like)
select * from articulos where nombre like '%lampara%'
-- k-   artículos que su precio sea menor que 200 y en su nombre no contenga la letra 'a'

-- 	2- Listar los artículos ordenados por precio de mayor a menor, y si hubiera precio iguales deben 
--     quedar ordenados por nombre.
select * from articulos order by precio desc, nombre;

-- 	3- Listar todos los artículos incluyendo una columna denominada precio con IVA, la cual deberá 
--     tener el monto con el iva del producto.
select codigo, nombre, precio, round(precio*1.21, 2) precio_con_iva, stock from articulos;

-- 	4- Listar todos los artículos incluyendo una columna denominada 'cantidad de cuotas' 
--     y otra 'valor de cuota', la cantidad es fija y es 3, 
--     el valor de cuota corresponde a 1/3 del monto con un 5% de interés.
select codigo, nombre, precio, 3 cantidad_de_cuotas, round(precio/3*1.05,2) valor_cuota, stock 
    from articulos;
