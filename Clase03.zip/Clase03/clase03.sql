-- Linea de comentarios
/* Bloque de comentarios */
#Linea de comentarios NO ANSI

show databases;		-- muestra las BDs de server

-- ; es el terminador de sentencia
-- CTROL - ENTER	para ejecutar

SHOW DATABASES;		-- lenguaje no case sensitive

drop database if exists clase03;		-- borra la base de datos clase01
create database clase03;				-- Crea la BD clase01 

use clase03;							-- Activa la BD

show tables;							-- Muestra el catalogo de tablas

-- borramos la tabla de clientes
drop table if exists clientes;

-- creamos la tabla clientes
create table clientes (
	codigo int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    cuit char(11),                       -- 11
    direccion varchar(50),
    comentarios varchar(150)
);

-- campos: son columnas
-- registros: con filas

describe clientes;					-- Muestra el metadato - describe la tabla

select * from clientes;				-- lista los registros de la tabla clientes

-- insertamos un registro en tabla clientes
insert into clientes (nombre, apellido, cuit, direccion) 
	values ('Ana','Gallardo','1234567','Lima 123');


-- extensión para MySQL MySQL cweijan

-- ------------------------
-- Definiciones importantes
-- ------------------------


-- Significado de SQL
-- Structured Query Language

-- ANSI SQL
-- En la actualidad el SQL es el estándar de facto de la inmensa mayoría de los SGBD comerciales.
-- Y, aunque la diversidad de añadidos particulares que incluyen las distintas implementaciones
-- comerciales del lenguaje es amplia, el soporte al estándar SQL-92 es general y muy amplio.


-- DDL (DATA DEFINITION LANGUAGE)
-- Create table
-- Alter table
-- Drop table

-- DML (DATA MANIPULATION LANGUAGE)
-- Select
-- Insert
-- Update
-- Delete

-- DCL (DATA CONTROL LANGUAGE)
-- Programación (No incluida en este curso)

-- -----------------------------------
-- Tipos de datos más comunes en MySQL
-- -----------------------------------


-- Tipo de datos Texto de datos más comunes

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- char(x)		x
-- varchar(x)	x+1

/*
		nombre char(20),
        
        |ANA                 |				20 bytes
		|CARLOS              |				20 bytes
        |MAXIMILIANO         |				20 bytes
        |MARIA TERESA        |				20 bytes
									Total	80 bytes
                                    
		nombre varchar(20)
        |ANA                 |				  3 + 1 = 4  bytes
		|CARLOS              |				  6 + 1 = 7	 bytes
        |MAXIMILIANO         |				 11 + 1 =12  bytes
        |MARIA TERESA        |				 12 + 1 =13  bytes
									Total	36 bytes
*/


-- Tipo de datos Numérico

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- bool (boolean)	1	(0 es false distinto de 0 es true)
-- tinyint			1	2^8			256
-- smallint			2	2^16		65536
-- mediumint		3	2^24		16777216
-- int (integer)	4	2^32		4294967296
-- bigint			8	2^64		18446744073709551616
-- float			4	 		
-- double			8
-- decimal(t,d)		t+2 

/*
		codigo tinyint			(signed)
        
        |--------|--------|
	  -128		 0       127
        
        codigo tinyint unsigned

		|-----------------|
		0				 255
        
        valor float,
        10/3
        3.333333
        --------
        
        100/3
        33.33333
        --------
        
        valor double
        10/3
        3.33333333333333
        ----------------
        
        100/3
        33.3333333333333
        ----------------
        
        
		precio decimal(8,2)
        999999,99
        ------,--
        
        precio decimal(6,3)
        999,999
        ---,---

*/



-- Tipo de datos Fecha y Hora

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- date		3	Año Mes Dia ‘2012-10-25’	    '2025/08/19'
-- datetime	8
-- time		3
-- year		1

select 'Hola Mundo';
select 2 + 2;           -- 4

-- Uso del Alias
select 2 + 2 total;
select 2 + 2 'valor total';
select 2 + 2 valor_total;
select PI() PI;
select ROUND(PI(),2) PI;

select CURDATE() Fecha;             -- Fecha del server
select CURTIME() Hora;              -- Hora del server    
select SYSDATE() fecha_hora;

-- Actividad 1
-- 1- Borrar si existe la base de datos Agenda.
DROP DATABASE if EXISTS agenda;
-- 2- Crear la base de datos Agenda.
CREATE DATABASE agenda;
-- 3- Ingresar a la base de datos creada.
USE agenda;

-- 4- Crear una tabla llamada "agenda". Debe tener los siguientes campos:
--    nombre (cadena de 20), 
--    domicilio (cadena de 30)
--    telefono (cadena de 11)
CREATE TABLE agenda(
    nombre VARCHAR(20),
    domicilio VARCHAR(30),
    telefono VARCHAR(11)
);

-- 5- Visualizar las tablas existentes en la base de datos para verificar la creación de "agenda".
SHOW TABLES;
-- 6- Visualizar la estructura de campos de la tabla "agenda". (describe).
DESCRIBE agenda;
-- 7- Ingresar 10 registros con valores aleatorios.
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Juan Pérez', 'Av. Libertador 123', '5551234567');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('María López', 'Calle 45 #67', '5552345678');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Carlos Sánchez', 'Paseo de la Reforma 89', '5553456789');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Ana Gómez', 'Calle de la Paz 10', '5554567890');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Luis Martínez', 'Av. de los Insurgentes 300', '5555678901');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Laura Torres', 'Calle 12 #34', '5556789012');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Pedro Ramírez', 'Blvd. Adolfo López Mateos 45', '5557890123');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Sofia Hernández', 'Calle 80 #90', '5558901234');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Jorge Díaz', 'Av. Chapultepec 56', '5559012345');
INSERT INTO agenda (nombre, domicilio, telefono) VALUES ('Claudia Ruiz', 'Calle 7 #8', '5550123456');

-- 8- Seleccione y muestre todos los registros de la tabla:
SELECT * FROM agenda;

-- Felicitaciones usted ha armado su agenda personal!!!!

