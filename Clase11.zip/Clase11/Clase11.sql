-- Laboratorio
-- Crear la base de datos laboratorio_06, si ya existe borrarla.
drop database if exists laboratorio_06;
create database laboratorio_06;
use laboratorio_06;

show databases;


-- Crear la siguiente tabla.
create table cursos(
	codigo int,
	nombre varchar(50),
	dias varchar(10),
	inscriptos int,
	primary key(codigo)
);

insert into cursos values
	(1,'PHP','lunes',10),
	(2,'Java','lunes',5),
	(3,'Corel Draw','martes',2),
	(4,'Java','martes',5),
	(5,'MySQL','martes',5),
	(6,'Oracle','miercoles',6),
	(7,'C#.net','jueves',5),
	(8,'C#.net','viernes',4),
	(9,'PHP','lunes',10),
	(10,'C#.net','lunes',5),
	(11,'Corel Draw','martes',2),
	(12,'Oracle','martes',5),
	(13,'PHP','martes',5),
	(14,'Oracle','miércoles',6),
	(15,'C#.net','jueves',5),
	(16,'Java','viernes',4);

INSERT INTO cursos (codigo, nombre, dias, inscriptos) VALUES
(101, 'Matemáticas', 'Lunes', 25),
(102, 'Física', 'Martes', 30),
(103, 'Química', 'Miércoles', 20),
(104, 'Biología', 'Jueves', 15),
(105, 'Historia', 'Viernes', 40),
(106, 'Literatura', 'Lunes', 22),
(107, 'Geografía', 'Martes', 28),
(108, 'Arte', 'Miércoles', 18),
(109, 'Música', 'Jueves', 12),
(1010, 'Programación', 'Viernes', 35),
(111, 'Economía', 'Lunes', 27),
(112, 'Filosofía', 'Martes', 10),
(113, 'Psicología', 'Miércoles', 24),
(114, 'Sociología', 'Jueves', 21),
(115, 'Educación Física', 'Viernes', 29),
(116, 'Robótica', 'Lunes', 19),
(117, 'Astronomía', 'Martes', 14),
(118, 'Ciencias Políticas', 'Miércoles', 26),
(119, 'Derecho', 'Jueves', 32),
(120, 'Antropología', 'Viernes', 33),
(121, 'Diseño Gráfico', 'Lunes', 11),
(122, 'Cine', 'Martes', 17),
(123, 'Fotografía', 'Miércoles', 23),
(124, 'Gastronomía', 'Jueves', 30),
(125, 'Idiomas', 'Viernes', 36),
(126, 'Matemáticas', 'Lunes', 15),
(127, 'Estadística', 'Martes', 28),
(128, 'Contabilidad', 'Miércoles', 19),
(129, 'Marketing', 'Jueves', 22),
(30, 'Gestión Empresarial', 'Viernes', 27),
(31, 'Ciencias de la Computación', 'Lunes', 40),
(32, 'Redes Sociales', 'Martes', 12),
(33, 'Desarrollo Web', 'Miércoles', 20),
(34, 'Aplicaciones Móviles', 'Jueves', 25),
(35, 'UX/UI Design', 'Viernes', 18),
(36, 'Bioquímica', 'Lunes', 10),
(37, 'Zoología', 'Martes', 15),
(38, 'Botánica', 'Miércoles', 28),
(39, 'Ecología', 'Jueves', 22),
(40, 'Genética', 'Viernes', 30),
(41, 'Teatro', 'Lunes', 16),
(42, 'Danza', 'Martes', 14),
(43, 'Ciencias de la Salud', 'Miércoles', 27),
(44, 'Nutrición', 'Jueves', 11),
(45, 'Logística', 'Viernes', 33),
(46, 'Comercio Internacional', 'Lunes', 19),
(47, 'Administración Pública', 'Martes', 24),
(48, 'Investigación de Mercados', 'Miércoles', 29),
(49, 'Finanzas', 'Jueves', 31),
(50, 'Gestión de Proyectos', 'Viernes', 35),
(51, 'Programación Avanzada', 'Lunes', 26),
(52, 'Ciberseguridad', 'Martes', 12),
(53, 'Machine Learning', 'Miércoles', 21),
(54, 'Inteligencia Artificial', 'Jueves', 30),
(55, 'Big Data', 'Viernes', 15),
(56, 'Blockchain', 'Lunes', 22),
(57, 'Cloud Computing', 'Martes', 18),
(58, 'DevOps', 'Miércoles', 20),
(59, 'Realidad Aumentada', 'Jueves', 14),
(60, 'Diseño de Juegos', 'Viernes', 29);

-- Según la tabla cursos
-- 1 - Sumar en uno la cantidad de alumnos inscriptos del curso Java de los días Lunes
update cursos set inscriptos=inscriptos+1 where nombre='Java' and dias='lunes';
-- 2 - Poner en 0 la cantidad de alumnos inscriptos de los cursos de los días Martes
update cursos set inscriptos=0 where dias='martes';
select * from cursos where dias='martes';
-- 3 - Borrar los cursos de Java en día Martes
set sql_safe_updates=0;
delete from cursos where nombre='Java' and dias='martes';
-- 4 - Sumar 5 inscriptos en los cursos que tengan menos de 5 alumnos inscriptos.
update cursos set inscriptos=inscriptos+5 where inscriptos<5;
-- 5 - Cambiar el nombre de los cursos Java por Java 2 SE.
update cursos set nombre='Java SE' where nombre='Java';

-- Ejercicio 2-- Crear la siguiente tabla.

use laboratorio_06;
create table empleados(
	codigo int auto_increment,
	nombre varchar(20) not null,
	apellido varchar(20) not null,
	seccion varchar(20),
	sueldo float,
	primary key (codigo)
);

insert into empleados (nombre,apellido,seccion,sueldo) values
	('juan','perez','administracion',72000),
	('diego','torres','ventas',35200),
	('laura','gomez','ventas',46000),
	('mario','lopez','produccion',45000),
	('dario','sanchez','administracion',86000),
	('juan','boneli','administracion',72000),
	('diego','martinez','ventas',35200),
	('laura','moretti','ventas',46000),
	('sandra','lazante','produccion',45000),
	('susana','mendez','administracion',86000);

INSERT INTO empleados (nombre, apellido, seccion, sueldo) VALUES
('Juan', 'Pérez', 'Ventas', 2500.50),
('María', 'González', 'Recursos Humanos', 3000.00),
('Luis', 'Martínez', 'Desarrollo', 4000.75),
('Ana', 'López', 'Marketing', 2800.00),
('Carlos', 'Hernández', 'Finanzas', 3200.50),
('Laura', 'Ramírez', 'IT', 4500.00),
('José', 'Cruz', 'Ventas', 2200.25),
('Sofía', 'Fernández', 'Recursos Humanos', 3100.00),
('Javier', 'Gutiérrez', 'Desarrollo', 4200.80),
('Elena', 'Mendoza', 'Marketing', 2900.40),
('Diego', 'Díaz', 'Finanzas', 3300.60),
('Patricia', 'Morales', 'IT', 4600.10),
('Fernando', 'Salazar', 'Ventas', 2400.90),
('Isabel', 'Torres', 'Recursos Humanos', 3050.40),
('Andrés', 'Jiménez', 'Desarrollo', 4100.30),
('Natalia', 'Ríos', 'Marketing', 2950.00),
('Roberto', 'Cano', 'Finanzas', 3400.70),
('Claudia', 'Núñez', 'IT', 4700.80),
('Ricardo', 'Vega', 'Ventas', 2300.00),
('Verónica', 'Sánchez', 'Recursos Humanos', 3000.35),
('Miguel', 'Alvarez', 'Desarrollo', 4300.90),
('Carmen', 'Castillo', 'Marketing', 2850.00),
('Samuel', 'Ponce', 'Finanzas', 3500.20),
('Gabriela', 'Cárdenas', 'IT', 4800.00),
('Alberto', 'Márquez', 'Ventas', 2600.50),
('Marisol', 'Luna', 'Recursos Humanos', 3150.60),
('Ezequiel', 'Peña', 'Desarrollo', 4400.10),
('Fatima', 'Rojas', 'Marketing', 2920.00),
('Leonardo', 'Salinas', 'Finanzas', 3600.80),
('Samantha', 'Serrano', 'IT', 4900.40),
('Cristian', 'Aguilar', 'Ventas', 2500.25),
('Patricia', 'Cruz', 'Recursos Humanos', 3250.50),
('Omar', 'Caldwell', 'Desarrollo', 4150.30),
('Rosario', 'García', 'Marketing', 2750.00),
('Hugo', 'Ortega', 'Finanzas', 3700.60),
('Mónica', 'Bermúdez', 'IT', 5000.00),
('Raúl', 'Cruz', 'Ventas', 2400.70),
('Silvia', 'Montalvo', 'Recursos Humanos', 3100.25),
('María', 'López', 'Desarrollo', 4050.90),
('Gabriel', 'Carmona', 'Marketing', 2900.60),
('Rosa', 'Vargas', 'Finanzas', 3800.10),
('Esteban', 'Rojas', 'IT', 5100.00),
('Victoria', 'Núñez', 'Ventas', 2550.00),
('Nicolás', 'Soto', 'Recursos Humanos', 3350.50),
('Ángela', 'Bautista', 'Desarrollo', 4200.20),
('Federico', 'Martínez', 'Marketing', 2800.40),
('Daniel', 'Salas', 'Finanzas', 3900.80),
('Mauricio', 'Pérez', 'IT', 5200.00),
INSERT INTO empleados (nombre, apellido, seccion, sueldo) VALUES
('Juan', 'Pérez', 'Ventas', 2500.50),
('María', 'González', 'Recursos Humanos', 3000.00),
('Luis', 'Martínez', 'Desarrollo', 4000.75),
('Ana', 'López', 'Marketing', 2800.00),
('Carlos', 'Hernández', 'Finanzas', 3200.50),
('Laura', 'Ramírez', 'IT', 4500.00),
('José', 'Cruz', 'Ventas', 2200.25),
('Sofía', 'Fernández', 'Recursos Humanos', 3100.00),
('Javier', 'Gutiérrez', 'Desarrollo', 4200.80),
('Elena', 'Mendoza', 'Marketing', 2900.40),
('Diego', 'Díaz', 'Finanzas', 3300.60),
('Patricia', 'Morales', 'IT', 4600.10),
('Fernando', 'Salazar', 'Ventas', 2400.90),
('Isabel', 'Torres', 'Recursos Humanos', 3050.40),
('Andrés', 'Jiménez', 'Desarrollo', 4100.30),
('Natalia', 'Ríos', 'Marketing', 2950.00),
('Roberto', 'Cano', 'Finanzas', 3400.70),
('Claudia', 'Núñez', 'IT', 4700.80),
('Ricardo', 'Vega', 'Ventas', 2300.00),
('Verónica', 'Sánchez', 'Recursos Humanos', 3000.35),
('Miguel', 'Alvarez', 'Desarrollo', 4300.90),
('Carmen', 'Castillo', 'Marketing', 2850.00),
('Samuel', 'Ponce', 'Finanzas', 3500.20),
('Gabriela', 'Cárdenas', 'IT', 4800.00),
('Alberto', 'Márquez', 'Ventas', 2600.50),
('Marisol', 'Luna', 'Recursos Humanos', 3150.60),
('Ezequiel', 'Peña', 'Desarrollo', 4400.10),
('Fatima', 'Rojas', 'Marketing', 2920.00),
('Leonardo', 'Salinas', 'Finanzas', 3600.80),
('Samantha', 'Serrano', 'IT', 4900.40),
('Cristian', 'Aguilar', 'Ventas', 2500.25),
('Patricia', 'Cruz', 'Recursos Humanos', 3250.50),
('Omar', 'Caldwell', 'Desarrollo', 4150.30),
('Rosario', 'García', 'Marketing', 2750.00),
('Hugo', 'Ortega', 'Finanzas', 3700.60),
('Mónica', 'Bermúdez', 'IT', 5000.00),
('Raúl', 'Cruz', 'Ventas', 2400.70),
('Silvia', 'Montalvo', 'Recursos Humanos', 3100.25),
('María', 'López', 'Desarrollo', 4050.90),
('Gabriel', 'Carmona', 'Marketing', 2900.60),
('Rosa', 'Vargas', 'Finanzas', 3800.10),
('Esteban', 'Rojas', 'IT', 5100.00),
('Victoria', 'Núñez', 'Ventas', 2550.00),
('Nicolás', 'Soto', 'Recursos Humanos', 3350.50),
('Ángela', 'Bautista', 'Desarrollo', 4200.20),
('Federico', 'Martínez', 'Marketing', 2800.40),
('Daniel', 'Salas', 'Finanzas', 3900.80),
('Mauricio', 'Pérez', 'IT', 5200.00),
('Verónica', 'Reyes', 'Ventas', 2650.30),
('Cristina', 'Hernández', 'Recursos Humanos', 3400.00),
('Evelyn', 'González', 'Desarrollo', 4250.10),
('José', 'Ramírez', 'Marketing', 3000.50),
('Raquel', 'Rodríguez', 'Finanzas', 4000.00),
('Silvia', 'López', 'IT', 5300.60),
('Luis', 'Castillo', 'Ventas', 2750.00),
('Patricia', 'Montoya', 'Recursos Humanos', 3150.80),
('Jorge', 'Serrano', 'Desarrollo', 4400.40),
('Inés', 'Salazar', 'Marketing', 2900.90),
('Patricio', 'Vázquez', 'Finanzas', 4100.00);
('Silvia', 'López', 'IT', 5300.60),
('Luis', 'Castillo', 'Ventas', 2750.00),
('Patricia', 'Montoya', 'Recursos Humanos', 3150.80),
('Jorge', 'Serrano', 'Desarrollo', 4400.40),
('Inés', 'Salazar', 'Marketing', 2900.90),
('Patricio', 'Vázquez', 'Finanzas', 4100.00);

-- 1 Cambiar al empleado Mario Lopez de la sección administración a producción.
update empleados set seccion='produccion' where nombre='Mario' and apellido='Lopez';

-- 2 Aplicar un aumento de sueldo básico del 15% a los empleados de ventas.
update empleados set sueldo=round(sueldo*1.15,2) where seccion='Ventas';

-- 3 Aplicar un aumento del 8% a todos los empleados de producción que tengan un
-- 		sueldo básico menor a 6000 pesos.
update empleados set sueldo=round(sueldo*1.08,2) where sueldo<6000;

-- 4 Dar de baja al empleado Susana Méndez.
delete from empleados where nombre='Susana' and apellido='Mendez';
-- 5 Aplicar un aumento de sueldo del 4% a todos los empleados que tengan un 
-- 		básico mayor o igual a 5000 pesos.
update empleados set sueldo=round(sueldo*1.04,2) where sueldo>=5000;
-- 6 Aplicar un aumento de sueldo del 8% a todos los empleados que tengan un 
-- 		básico menor a 5000 pesos.
update empleados set sueldo=round(sueldo*1.08,2) where sueldo<5000;
-- 7 Agregar el campo fecha de nacimiento (date) en la tabla empleados despues del campo apellido.
-- 8 Completar una fecha de nacimiento para cada empleado.
-- 9 Listar todos los campos de empleados + una columna que calcule la edad de cada empleado.
