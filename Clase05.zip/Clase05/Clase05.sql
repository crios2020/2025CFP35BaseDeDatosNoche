use negocio;

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '20-12345678-9', 'Calle Falsa 123', 'Cliente frecuente'),
('Ana', 'Gómez', '27-23456789-2', 'Avenida Siempre Viva 742', 'Interesada en descuentos'),
('Luis', 'Martínez', '30-34567890-5', 'Boulevard de los Sueños', 'Requiere atención especial'),
('María', 'López', '33-45678901-8', 'Ruta 66', 'Nuevo en la tienda'),
('Carlos', 'Fernández', '40-56789012-1', 'Calle de la Amistad 456', 'Compra regular'),
('Laura', 'Sánchez', '45-67890123-4', 'Av. Libertador 789', 'Consulta sobre productos'),
('Javier', 'Hernández', '50-78901234-7', 'Calle del Sol 321', 'Satisfecho con el servicio'),
('Sofía', 'Ramírez', '55-89012345-0', 'Calle del Río 654', 'Recomendado por un amigo'),
('Diego', 'Torres', '60-90123456-3', 'Plaza Mayor 987', 'Buscando promociones'),
('Clara', 'Jiménez', '65-01234567-6', 'Calle de la Paz 135', 'Interesada en productos ecológicos'),
('Fernando', 'García', '70-12345678-9', 'Calle del Bosque 246', 'Cliente nuevo'),
('Valentina', 'Mendoza', '75-23456789-2', 'Av. de la Revolución 357', 'Quiere recibir novedades'),
('Andrés', 'Castro', '80-34567890-5', 'Calle del Mar 468', 'Le gusta la variedad'),
('Isabel', 'Vargas', '85-45678901-8', 'Calle de los Héroes 579', 'Interesada en productos locales'),
('Ricardo', 'Rojas', '90-56789012-1', 'Avenida del Futuro 690', 'Busca productos premium'),
('Patricia', 'Cruz', '95-67890123-4', 'Calle de las Flores 801', 'Requiere atención personalizada'),
('Gabriel', 'Luna', '10-78901234-7', 'Calle del Viento 912', 'Cliente ocasional'),
('Marta', 'Salazar', '15-89012345-0', 'Calle de la Esperanza 123', 'Le gusta el servicio al cliente'),
('Hugo', 'Díaz', '20-90123456-3', 'Calle de los Abetos 234', 'Consulta frecuente'),
('Lucía', 'Moreno', '25-01234567-6', 'Calle de la Libertad 345', 'Interesada en eventos'),
('Oscar', 'Córdova', '30-12345678-9', 'Calle de la Amistad 456', 'Recomendado por familia'),
('Gina', 'Barrientos', '35-23456789-2', 'Avenida del Sol 567', 'Satisfecha con la compra'),
('Nicolás', 'Sierra', '40-34567890-5', 'Calle de los Naranjos 678', 'Buscando asesoramiento'),
('Selena', 'Paredes', '45-45678901-8', 'Avenida de los Olmos 789', 'Cliente fiel'),
('Ricardo', 'Ceballos', '50-56789012-1', 'Calle de los Cedros 890', 'Interesado en regalos'),
('Verónica', 'Cáceres', '55-67890123-4', 'Calle de la Alegría 135', 'Feliz con la atención'),
('Alberto', 'Villalobos', '60-78901234-7', 'Calle de la Amistad 246', 'Buscando calidad'),
('Carla', 'Alvarado', '65-89012345-0', 'Calle del Río 357', 'Requiere más información'),
('Jorge', 'González', '70-90123456-3', 'Calle del Mar 468', 'Cliente esporádico'),
('Diana', 'Peralta', '75-01234567-6', 'Calle de la Luna 579', 'Interesada en novedades'),
('Esteban', 'Maldonado', '80-12345678-9', 'Calle de la Esperanza 690', 'Cliente satisfecho'),
('Patricio', 'Núñez', '85-23456789-2', 'Avenida del Futuro 801', 'Busca ofertas'),
('Gloria', 'Cruz', '90-34567890-5', 'Calle de la Paz 912', 'Requiere atención especial'),
('Silvia', 'García', '95-45678901-8', 'Calle de los Héroes 135', 'Cliente habitual'),
('Miguel', 'Alonso', '10-56789012-1', 'Calle del Bosque 246', 'Interesado en calidad'),
('Alicia', 'Vega', '15-67890123-4', 'Avenida de la Revolución 357', 'Consulta por productos'),
('Diego', 'Aguilar', '20-78901234-7', 'Calle del Río 468', 'Recomendado por un amigo'),
('Nadia', 'Salinas', '25-89012345-0', 'Plaza Mayor 579', 'Interesada en descuentos'),
('Fernando', 'Mendoza', '30-90123456-3', 'Calle de los Naranjos 680', 'Satisfecho con el servicio'),
('Luz', 'Soto', '35-01234567-6', 'Avenida del Sol 791', 'Le gusta la variedad'),
('Ramón', 'Vargas', '40-12345678-9', 'Calle de la Libertad 902', 'Busca productos premium'),
('Teresa', 'Ríos', '45-23456789-2', 'Calle de las Flores 135', 'Requiere atención personalizada'),
('Salvador', 'Cisneros', '50-34567890-5', 'Calle de los Cedros 246', 'Cliente ocasional'),
('Maribel', 'López', '55-45678901-8', 'Calle de la Amistad 357', 'Interesada en eventos'),
('Emilio', 'Córdova', '60-56789012-1', 'Calle de los Abetos 468', 'Recomendado por familia'),
('Fabiola', 'Salazar', '65-67890123-4', 'Calle del Viento 579', 'Satisfecha con la compra'),
('Pablo', 'Sierra', '70-78901234-7', 'Calle de la Alegría 680', 'Buscando asesoramiento'),
('Elena', 'Paredes', '75-89012345-0', 'Calle de la Libertad 791', 'Cliente fiel'),
('Cristian', 'Ceballos', '80-90123456-3', 'Calle de los Olmos 902', 'Interesado en regalos'),
('Gabriela', 'Cáceres', '85-01234567-6', 'Calle de los Héroes 135', 'Feliz con la atención'),
('Sergio', 'Moreno', '90-12345678-9', 'Calle de la Esperanza 246', 'Buscando calidad'),
('Luciana', 'Alvarado', '95-23456789-2', 'Avenida del Futuro 357', 'Requiere más información'),
('Joaquín', 'González', '10-34567890-5', 'Calle de los Cedros 468', 'Cliente esporádico'),
('Irene', 'Aguilar', '15-45678901-8', 'Calle del Río 579', 'Interesada en novedades'),
('Ramiro', 'Vega', '20-56789012-1', 'Calle del Mar 690', 'Cliente satisfecho'),
('Verónica', 'Núñez', '25-67890123-4', 'Calle de la Paz 801', 'Busca ofertas'),
('Ernesto', 'Alonso', '30-78901234-7', 'Calle de la Amistad 912', 'Requiere atención especial'),
('Patricia', 'Ríos', '35-89012345-0', 'Calle de los Héroes 135', 'Cliente habitual');

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
    ('A', 11001, curdate(), 2500.75),
    ('B', 12002, curdate(), 1500.50),
    ('C', 13003, curdate(), 3200.00),
    ('A', 11002, curdate(), 1800.30),
    ('B', 12003, curdate(), 2200.90);

-- comando DML Select

-- Cómodin *
select * from clientes;
select nombre, apellido, direccion from clientes;
select direccion, apellido, nombre from clientes;
select concat(nombre,' ',apellido) nombre from clientes;

-- filtrado con where
select * from clientes where nombre='ana';
select * from clientes where codigo<=3;
select * from clientes where codigo>20;
select * from clientes where codigo>=20;
select * from articulos where nombre='laptop';
select * from clientes where codigo>=30 and codigo<=50;
select * from facturas where fecha=curdate();
select * from facturas where fecha='2025/08/26';

select * from clientes where nombre='ana' and apellido='gomez';
select * from clientes where nombre='ana' or apellido='gomez';

-- Valores null
insert into clientes (nombre, apellido,direccion) values
	('Andrea','Moretti',null),
    ('Laura','Sosa','');

select * from clientes where direccion='';
select * from clientes where direccion is null;
select * from clientes where direccion is not null;
select * from clientes where direccion=null;		-- no funciona


-- Operador distinto != <>
select * from clientes where nombre!='Ana';
select * from clientes where nombre<>'Ana';

-- clausula in y not in
select * from clientes where codigo=1 or codigo=23 or codigo=28 or codigo=33;
select * from clientes where codigo in(1, 23, 28, 33);
select * from clientes where codigo not in(1, 23, 28, 33);
select * from clientes where codigo!=1 and codigo!=23 and codigo!=28 and codigo!=33;

-- clausula between not between
select * from facturas;
select * from facturas where monto>=1000 and monto<=2000;
select * from facturas where monto<1000 or monto>2000;
select * from facturas where monto between 1000 and 2000;
select * from facturas where monto not between 1000 and 2000;

-- clausula like not like
select * from clientes where nombre like 'm%';	
select * from clientes where nombre like 'ma%';	
select * from clientes where nombre like 'mar%';	
select * from clientes where nombre like '%a';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre like '___';	
select * from clientes where nombre like '____';
select * from clientes where nombre like '_____%';
select * from clientes where nombre like 'm_r%';
select * from clientes where nombre not like 'm%';

-- order by
select * from clientes;	
select * from clientes order by apellido;	
select * from clientes order by apellido asc;	
select * from clientes order by apellido desc;
select * from clientes order by apellido, nombre;

-- columnas calculadas
select letra,numero,fecha,monto from facturas;
select letra,numero,fecha,monto, round(monto*1.21, 2) monto_con_iva from facturas;


-- 1 - Ingrese a la base de datos negocio.

-- 2 - Ingrese 5 registros aleatorios en cada tabla.

-- 3 - Basándose en la tabla artículos obtener los siguientes listados.

-- a-	artículos con precio mayor a 100
-- b-	artículos con precio entre 20 y 40 (usar < y >)
-- c-	artículos con precio entre 40 y 60 (usar BETWEEN)
-- d-	artículos con precio = 20 y stock mayor a 30
-- e-	artículos con precio (12,20,30) no usar IN
-- f-	artículos con precio (12,20,30) usar el IN
-- g-	artículos que su precio no sea (12,20,30)
-- h-   artículos que su precio mas iva(21 %) sea mayor a 100
-- i-   listar nombre y descripción de los artículos que no cuesten $100
-- j- 	artículos con nombre que contengan la cadena 'lampara' (usar like)
-- k-   artículos que su precio sea menor que 200 y en su nombre no contenga la letra 'a'

-- 	2- Listar los artículos ordenados por precio de mayor a menor, y si hubiera precio iguales deben quedar ordenados por nombre.
-- 	3- Listar todos los artículos incluyendo una columna denominada precio con IVA, la cual deberá tener el monto con el iva del producto.
-- 	4- Listar todos los artículos incluyendo una columna denominada 'cantidad de cuotas' y otra 'valor de cuota', la cantidad es fija y es 3, 
--     el valor de cuota corresponde a 1/3 del monto con un 5% de interés.
	
							

			







