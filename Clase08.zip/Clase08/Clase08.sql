-- Laboratorio 
-- Usando la base de datos negocio.
use negocio;

-- Basándose en la tabla clientes realizar los siguientes puntos.

-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
insert into clientes values 
    (null,'Juan','Perez','4525443','Lima 22',''),
    (null,'Ana','Moreno','5465453','Viel 233',''),
    (null,'María','Mendoza','7546776','Maipu 341',''),
    (null,'Debora','Moretti','65767576','Paso 43243',''),
    (null,'Martin','Salinas','676756','Pasco 2322','');

-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
insert into clientes (nombre,apellido,direccion) values
    ('Diego','Gomez','medrano 222'),
    ('Carlos','Rios','Lavalle 333'),
    ('Andrea','Alvarez','Arengreen 233'),
    ('Brenda','Tonio','Rivadavia 3343'),
    ('Macarena','Mendez','Mitre 9393');

-- 3-	Actualizar el nombre del cliente 1 a Jose.
select * from clientes;
truncate clientes;          -- borra la tabla y reinicia el auto-increment
update clientes set nombre='Jose' where codigo=1;

-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
update clientes set nombre='Pablo', apellido='Fuentes', cuit='20-21053119-0' where codigo=3;

-- 5-	Actualizar todos los comentarios NULL  a ''.
update clientes set comentarios='' where comentarios is null;
-- 6-	Eliminar los clientes con apellido Perez.
delete from clientes where apellido='Perez';
-- 7-	Eliminar los clientes con CUIT Terminan en 0.
delete from clientes where cuit like '%0';

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
update articulos set precio=round(precio*1.2,2) where precio<=50;

-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
update articulos set precio=round(precio*1.15,2) where precio>50;

-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
update articulos set precio=round(precio*0.95,2) where precio>200;

-- 	11- Eliminar los artículos con stock menor a 0.
delete from articulos where stock<0;

-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
alter table articulos add stockMinimo int;
alter table articulos add stockMaximo int;
describe articulos;
select * from articulos;
--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
update articulos set stockMinimo=20, stockMaximo=40;
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
select codigo,nombre, precio, stock, stockMinimo, stockMaximo, stockMaximo-stock cantidad_a_reponer 
    from articulos where stock<stockMinimo;
--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
select sum(stock*precio) valor_total from articulos;
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.
select round(sum(stock*precio)*1.21,2) valor_total_iva from articulos;
