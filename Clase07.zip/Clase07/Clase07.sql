use negocio;

-- Comando DML insert

-- insert normal con declaración de campos          ANSI
insert into clientes (nombre, apellido, direccion) values 
    ('Ana','Gomez','Viel 234');

insert into clientes (apellido, direccion, nombre) values 
    ('Perez','Larrea 545','Juan Manuel');

-- insert abreviado sin declaración de campos       ANSI
insert into clientes values 
    (null,'Mariana','Moretti','1235465','Pasco 344','');
insert into clientes values 
    (null,'Mariana','Moretti','1235465','Pasco 344','');
insert into clientes values 
    (null,'Mariana','Moretti','1235465','Pasco 344','');


-- insert SET NO ANSI
insert clientes set nombre='Dario', apellido='Segovia', direccion='Paso 234';

-- insert NO ANSI
insert clientes (nombre, apellido, direccion) values 
    ('Ana','Gomez','Viel 234');

-- insert masivo ANSI
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES 
('Juan', 'Pérez', '20-12345678-9', 'Av. Siempre Viva 742', 'Cliente frecuente'),
('María', 'Gómez', '20-87654321-0', 'Calle Falsa 123', 'Interesada en promociones'),
('Carlos', 'López', '20-11223344-5', 'Paseo de la Reforma 456', 'Requiere atención especial'),
('Ana', 'Martínez', '20-99887766-1', 'Av. Libertador 789', 'Prefiere contacto');



-- Comando DML update       ANSI
update clientes set nombre='Omar', apellido='Pereyra' where codigo=3;

-- OJO - CUIDADO - Update masivo
UPDATE clientes set nombre='María';

select * from clientes; 

-- Comando DML delete       ANSI
delete from clientes where codigo=4;

-- OJO - CUIDADO - Delete masivo
delete from clientes;

-- Laboratorio 
-- Usando la base de datos negocio.

-- Basándose en la tabla clientes realizar los siguientes puntos.

-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
-- 3-	Actualizar el nombre del cliente 1 a Jose.
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
-- 5-	Actualizar todos los comentarios NULL  a ''.
-- 6-	Eliminar los clientes con apellido Perez.
-- 7-	Eliminar los clientes con CUIT Terminan en 0.

-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
-- 	11- Eliminar los artículos con stock menor a 0.

-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.


